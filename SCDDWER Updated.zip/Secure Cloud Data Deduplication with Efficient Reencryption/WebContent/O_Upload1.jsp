<%@page import="java.util.Date"%>
<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>

<%@ include file="connect.jsp" %>

<%@ page import="
    java.io.*,
    java.sql.*,
    java.util.*,
    java.text.SimpleDateFormat,
    java.security.*,
    java.math.BigInteger,
    javax.crypto.*,
    javax.crypto.spec.SecretKeySpec,
    java.util.Base64
"%>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Upload</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="css/style.css" rel="stylesheet" type="text/css" />
</head>

<body>
<div class="main">
<div class="content">
<div class="content_resize">
<div class="article">

<h2>Uploading File Details</h2>

<%
try {

    String file = request.getParameter("tt");
    String cont = request.getParameter("text");

    /* ================= SAFE UPLOAD PATH ================= */
    String uploadPath = application.getRealPath("/") + "uploads";
    File dir = new File(uploadPath);
    if (!dir.exists()) {
        dir.mkdirs();
    }

    String tempFile = uploadPath + File.separator + "temp_" + System.currentTimeMillis() + ".txt";

    /* ================= AES ENCRYPTION ================= */
    String secretKey = "ef50a0ef2c3e3a5f"; // 16 bytes
    byte[] keyBytes = secretKey.getBytes("UTF-8");
    Key aesKey = new SecretKeySpec(keyBytes, "AES");

    Cipher cipher = Cipher.getInstance("AES");
    cipher.init(Cipher.ENCRYPT_MODE, aesKey);

    byte[] encryptedBytes = cipher.doFinal(cont.getBytes("UTF-8"));
    String encryptedValue = Base64.getEncoder().encodeToString(encryptedBytes);

    /* ================= WRITE FILE ================= */
    try (FileOutputStream fos = new FileOutputStream(tempFile);
         PrintStream ps = new PrintStream(fos)) {
        ps.print(cont);
    }

    /* ================= SHA-1 HASH ================= */
    MessageDigest md = MessageDigest.getInstance("SHA-1");

    try (FileInputStream fis = new FileInputStream(tempFile);
         DigestInputStream dis = new DigestInputStream(fis, md)) {
        while (dis.read() != -1) {}
    }

    BigInteger bi = new BigInteger(1, md.digest());
    String h1 = bi.toString(16);

    /* ================= DUPLICATE CHECK ================= */
    Statement st = connection.createStatement();
    ResultSet rs = st.executeQuery(
        "SELECT * FROM cloudserver WHERE mac='" + h1 + "'"
    );

    if (!rs.next()) {
%>

<form action="O_Upload2.jsp" method="post">
<table border="1" align="center" width="600">

<tr>
<td>File Name</td>
<td>
<input type="text" name="t42" value="<%=file%>" readonly size="50"/>
</td>
</tr>

<tr>
<td>Encrypted Content</td>
<td>
<textarea name="text2" rows="12" cols="50" readonly>
<%= encryptedValue %>
</textarea>
</td>
</tr>

<tr>
<td>Trapdoor (SHA-1)</td>
<td>
<input type="text" name="t4" value="<%=h1%>" readonly size="50"/>
</td>
</tr>

<tr>
<td></td>
<td>
<input type="submit" value="Upload"/>
</td>
</tr>

</table>
</form>

<%
    } else {

        Date now = new Date();
        SimpleDateFormat sdfDate = new SimpleDateFormat("dd/MM/yyyy");
        SimpleDateFormat sdfTime = new SimpleDateFormat("HH:mm:ss");
        String dt = sdfDate.format(now) + " " + sdfTime.format(now);

        String oname = (String) application.getAttribute("doname");

        connection.createStatement().executeUpdate(
            "INSERT INTO dduplicate(oname,fname,mac,dt) VALUES('" +
            oname + "','" + file + "','" + h1 + "','" + dt + "')"
        );
%>

<h2 style="color:red;">
DATA DUPLICATION FOUND! FILE ALREADY EXISTS IN CLOUD SERVER
</h2>

<%
    }

    connection.close();

} catch (Exception e) {
    out.println("<h3 style='color:red'>ERROR : " + e.getMessage() + "</h3>");
}
%>

<br/>
<a href="O_Main.jsp">⬅ Back</a>

</div>
</div>
</div>
</div>
</body>
</html>
