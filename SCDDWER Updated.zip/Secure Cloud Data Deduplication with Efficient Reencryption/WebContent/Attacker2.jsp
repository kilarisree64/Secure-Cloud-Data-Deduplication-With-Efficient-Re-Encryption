<%@page import="java.util.Date"%>
<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>

<%@ include file="connect.jsp"%>

<%@ page import="
    java.io.*,
    java.sql.*,
    java.util.*,
    java.text.SimpleDateFormat,
    java.security.*,
    java.math.BigInteger,
    javax.crypto.*,
    javax.crypto.spec.SecretKeySpec,
    java.util.Base64
"%>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
 "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Cross_Site_Attacker</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="css/style.css" rel="stylesheet" type="text/css" />
</head>

<body>
<div class="main">
<div class="content">
<div class="content_resize">
<div class="article">

<h2>External Attacker</h2>

<%
try {

    String file = request.getParameter("t1");
    String on = request.getParameter("t12");
    String cont = request.getParameter("text");

    /* ================= SAFE FILE PATH ================= */
    String uploadPath = application.getRealPath("/") + "uploads";
    File dir = new File(uploadPath);
    if (!dir.exists()) {
        dir.mkdirs();
    }

    String tempFile = uploadPath + File.separator + "attack_" + System.currentTimeMillis() + ".txt";

    /* ================= AES ENCRYPTION ================= */
    String secretKey = "ef50a0ef2c3e3a5f"; // 16 bytes
    byte[] keyBytes = secretKey.getBytes("UTF-8");
    Key aesKey = new SecretKeySpec(keyBytes, "AES");

    Cipher cipher = Cipher.getInstance("AES");
    cipher.init(Cipher.ENCRYPT_MODE, aesKey);

    byte[] encryptedBytes = cipher.doFinal(cont.getBytes("UTF-8"));
    String encryptedValue = Base64.getEncoder().encodeToString(encryptedBytes);

    /* ================= WRITE FILE ================= */
    try (FileOutputStream fos = new FileOutputStream(tempFile);
         PrintStream ps = new PrintStream(fos)) {
        ps.print(cont);
    }

    /* ================= SHA-1 HASH ================= */
    MessageDigest md = MessageDigest.getInstance("SHA-1");

    try (FileInputStream fis = new FileInputStream(tempFile);
         DigestInputStream dis = new DigestInputStream(fis, md)) {
        while (dis.read() != -1) {}
    }

    BigInteger bi = new BigInteger(1, md.digest());
    String h1 = bi.toString(16);

    /* ================= RSA KEY GENERATION ================= */
    KeyPairGenerator kpg = KeyPairGenerator.getInstance("RSA");
    kpg.initialize(1024);
    KeyPair kp = kpg.generateKeyPair();
    String pk = Base64.getEncoder().encodeToString(kp.getPublic().getEncoded());

    /* ================= FETCH FILE DETAILS ================= */
    Statement st = connection.createStatement();
    ResultSet rs = st.executeQuery(
        "SELECT * FROM cloudserver WHERE fname='" + file + "'"
    );

    int id = 0;
    if (rs.next()) {
        id = rs.getInt(1);
    }

    /* ================= DATE & TIME ================= */
    Date now = new Date();
    SimpleDateFormat sdfDate = new SimpleDateFormat("dd/MM/yyyy");
    SimpleDateFormat sdfTime = new SimpleDateFormat("HH:mm:ss");
    String dt = sdfDate.format(now) + " " + sdfTime.format(now);

    /* ================= UPDATE CLOUD DATA ================= */
    String updateQuery =
        "UPDATE cloudserver SET ct='" + cont +
        "', mac='" + h1 +
        "', sk='" + pk +
        "' WHERE fname='" + file + "'";

    connection.createStatement().executeUpdate(updateQuery);

    /* ================= ATTACK LOG ================= */
    String type = "Malicious Data Attack";
    String logQuery =
        "INSERT INTO attacker(user,fname,sk,type,dt) VALUES('" +
        on + "','" + file + "','" + pk + "','" + type + "','" + dt + "')";

    connection.createStatement().executeUpdate(logQuery);

%>

<h2 style="color:red; font-weight:bold;">
Attacked Successfully !!!
</h2>

<%
    connection.close();

} catch (Exception e) {
    out.println("<h3 style='color:red'>ERROR : " + e.getMessage() + "</h3>");
    e.printStackTrace();
}
%>

<br/>
<a href="C_Main.jsp">⬅ Back</a>

</div>
</div>
</div>
</div>
</body>
</html>
